import connectEvents from "./events";
export default connectEvents;
export { connectEvents };
