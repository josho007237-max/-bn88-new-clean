// noop matcher shim for tests
