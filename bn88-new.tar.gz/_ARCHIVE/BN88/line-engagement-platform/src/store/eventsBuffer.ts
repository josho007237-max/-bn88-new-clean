export const eventsBuffer: any[] = [];
