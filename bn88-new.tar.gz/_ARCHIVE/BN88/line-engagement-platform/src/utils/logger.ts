export const log = (...args: any[]) => console.log('[LOG]', ...args);
