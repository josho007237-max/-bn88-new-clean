// src/services/chatCore.ts
// ตอนนี้ logic หลักจัดการข้อความ อยู่ใน src/routes/webhooks/line.ts และ telegram.ts
// ไฟล์นี้เราเก็บไว้เผื่อ refactor ภายหลัง เลย export ว่าง ๆ เพื่อไม่ให้ TypeScript error

export {};
