-- AlterTable
ALTER TABLE "BotSecret" ADD COLUMN "lineChannelAccessToken" TEXT;
ALTER TABLE "BotSecret" ADD COLUMN "lineChannelSecret" TEXT;
