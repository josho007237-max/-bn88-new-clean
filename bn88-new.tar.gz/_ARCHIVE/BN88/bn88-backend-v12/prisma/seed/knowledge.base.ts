// prisma/seed/knowledge.base.ts
import type { PrismaClient } from "@prisma/client";

type SeedChunk = {
  orderIndex: number;
  heading: string;
  content: string;
};

type SeedDoc = {
  title: string;
  tags?: string;
  body?: string;
  status?: "active" | "draft" | "archived";
  chunks: SeedChunk[];
};

const DEFAULT_TENANT = "bn9";

const SEED_DOCS: SeedDoc[] = [
  {
    title: "สมัครสมาชิก",
    tags: "faq,register,สมัคร",
    body:
      "คู่มือสำหรับการสมัครสมาชิกเบื้องต้น วิธีขอ USER, เงื่อนไขการสมัคร และข้อควรระวังต่าง ๆ",
    status: "active",
    chunks: [
      {
        orderIndex: 1,
        heading: "วิธีสมัครสมาชิกผ่าน LINE",
        content:
          "ลูกค้าสามารถสมัครสมาชิกได้โดยการกดที่เมนูสมัครสมาชิกในหน้าแชท LINE จากนั้นกรอกชื่อ–นามสกุล และเบอร์โทรให้ครบ รอระบบส่ง USER และรหัสผ่านกลับให้ในแชทภายในไม่กี่นาที",
      },
      {
        orderIndex: 2,
        heading: "เงื่อนไขการสมัคร",
        content:
          "1) ต้องใช้เบอร์โทรที่ติดต่อได้จริง\n2) 1 เบอร์โทร / 1 บัญชีเท่านั้น ห้ามสมัครซ้ำ\n3) ข้อมูลที่ใช้สมัครต้องเป็นข้อมูลจริง เพื่อป้องกันปัญหาฝาก–ถอนในอนาคต",
      },
    ],
  },
  {
    title: "การฝาก–ถอนเงิน",
    tags: "faq,deposit,withdraw,ฝาก,ถอน",
    body:
      "อธิบายขั้นตอนการฝาก–ถอน วิธีแนบสลิป แจ้งปัญหาฝากไม่เข้า และระยะเวลาการตรวจสอบโดยทีมงาน",
    status: "active",
    chunks: [
      {
        orderIndex: 1,
        heading: "วิธีฝากเงินแบบปกติ",
        content:
          "ให้ลูกค้าเข้าเมนูฝากเงิน เลือกธนาคารที่ต้องการ แล้วโอนตามจำนวนที่ระบบแสดง จากนั้นแนบสลิปในแชท หรือกดปุ่มแจ้งฝาก ระบบจะตรวจสอบยอดและเติมเครดิตให้อัตโนมัติภายใน 1–5 นาที",
      },
      {
        orderIndex: 2,
        heading: "หากฝากแล้วเงินไม่เข้า",
        content:
          "หากลูกค้าฝากเงินไปแล้วเกิน 10 นาทีแล้วยอดยังไม่เข้า ให้แจ้งข้อมูลดังนี้: USER, ชื่อจริง, ธนาคารที่ใช้โอน, เลขบัญชี, ยอดที่โอน, เวลาโอนโดยประมาณ และแนบสลิป ระบบจะส่งเรื่องให้ทีมงานตรวจสอบภายใน 5–15 นาที",
      },
      {
        orderIndex: 3,
        heading: "การถอนเงิน",
        content:
          "การถอนเงินให้ลูกค้าเข้าเมนูถอน กรอกจำนวนเงินที่ต้องการถอน ระบบจะโอนกลับไปยังบัญชีที่ผูกไว้ปกติใช้เวลาทำรายการประมาณ 5–15 นาที ทั้งนี้ขึ้นอยู่กับธนาคารปลายทางด้วย",
      },
    ],
  },
];

async function upsertKnowledgeDoc(
  prisma: PrismaClient,
  tenant: string,
  doc: SeedDoc
) {
  const existing = await prisma.knowledgeDoc.findFirst({
    where: {
      tenant,
      title: doc.title,
    },
  });

  if (existing) {
    return existing;
  }

  // 🔴 จุดสำคัญ: model KnowledgeDoc ไม่มี field body / tags
  // ใช้ description แทน โดยเอา body + tags มารวมกันเป็นข้อความเดียว
  const descriptionParts: string[] = [];
  if (doc.body && doc.body.trim()) descriptionParts.push(doc.body.trim());
  if (doc.tags && doc.tags.trim())
    descriptionParts.push(`แท็ก: ${doc.tags.trim()}`);

  const description =
    descriptionParts.length > 0 ? descriptionParts.join("\n\n") : null;

  return prisma.knowledgeDoc.create({
    data: {
      tenant,
      title: doc.title,
      status: doc.status ?? "active",
      description,
    },
  });
}

export async function seedKnowledgeBase(
  prisma: PrismaClient,
  tenant: string = DEFAULT_TENANT
) {
  console.log(`[seedKnowledgeBase] seeding knowledge for tenant="${tenant}"`);

  for (const doc of SEED_DOCS) {
    const kd = await upsertKnowledgeDoc(prisma, tenant, doc);

    await prisma.knowledgeChunk.deleteMany({
      where: { tenant, docId: kd.id },
    });

    if (doc.chunks.length === 0) continue;

    await prisma.knowledgeChunk.createMany({
      data: doc.chunks.map((c) => ({
        tenant,
        docId: kd.id,
        orderIndex: c.orderIndex,
        heading: c.heading,
        content: c.content,
        embedding: [],
        tokens: 0,
      })),
    });

    console.log(
      `[seedKnowledgeBase] doc "${doc.title}" seeded with ${doc.chunks.length} chunks`
    );
  }

  console.log("[seedKnowledgeBase] done");
}
