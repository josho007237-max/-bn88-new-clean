# BN9 Backend (v2)

## Dev
npm i
npx prisma migrate dev
npm run dev

## ENV
ดู .env.example แล้วคัดลอกเป็น .env
