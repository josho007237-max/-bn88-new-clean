// bn88-frontend-dashboard-v12/src/api.ts
const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:3000";

/**
 * ถ้าคุณมีระบบ auth แบบ Bearer token:
 * - เก็บ token ใน localStorage key = "auth_token"
 * - ฟังก์ชันนี้จะใส่ Authorization ให้อัตโนมัติ
 *
 * ถ้าคุณใช้ cookie-based session:
 * - fetch ใช้ credentials: "include" ไว้แล้ว
 */
function getAuthToken(): string | null {
  try {
    return localStorage.getItem("auth_token");
  } catch {
    return null;
  }
}

async function j<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {});
  const token = getAuthToken();

  // ใส่ token ถ้ามี
  if (token && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  // ถ้ามี body เป็น object ให้ส่งเป็น JSON
  const isBodyObject =
    init.body &&
    typeof init.body === "object" &&
    !(init.body instanceof FormData) &&
    !(init.body instanceof Blob) &&
    !(init.body instanceof ArrayBuffer);

  let body = init.body;
  if (isBodyObject) {
    headers.set("Content-Type", "application/json");
    body = JSON.stringify(init.body);
  } else if (init.body && typeof init.body === "string") {
    // ถ้าส่ง string แล้วอย่าทับ content-type
  }

  const r = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers,
    body,
    credentials: "include",
  });

  if (!r.ok) {
    const text = await r.text().catch(() => "");
    throw new Error(`${r.status} ${text || r.statusText}`);
  }

  // บาง endpoint อาจคืน 204
  if (r.status === 204) return undefined as T;

  return r.json();
}

/* ----------------------------- Types: Common ----------------------------- */

export type Health = { ok: boolean; time: string; adminApi?: boolean };

export type StatDaily = {
  botId: string;
  dateKey: string;
  total: number;
  text: number;
  follow: number;
  unfollow: number;
};

export type DailyResp = { ok: boolean; dateKey: string; stats: StatDaily };

export type CaseItem = {
  id: string;
  botId: string;
  userId?: string | null;
  text?: string | null;
  kind?: string | null;
  createdAt?: string;
};

export type RecentResp = { ok: boolean; items: CaseItem[] };

/* ----------------------------- Types: Bots ------------------------------ */

export type Bot = {
  id: string;
  tenant: string;
  name: string;
  platform: string;
  isActive?: boolean;
};

export type BotsResp = { ok: boolean; items: Bot[] };

/* --------------------------- Types: Chat Center -------------------------- */

export type ChatSession = {
  id: string; // IMPORTANT: sessionId ที่ต้องใช้โหลดข้อความ
  botId: string;
  tenant?: string;
  platform: "line" | "telegram" | "facebook" | string;
  userId?: string | null; // LINE userId / platform user id
  displayName?: string | null;
  lastMessageAt?: string | null;
  updatedAt?: string | null;
  createdAt?: string | null;

  // optional preview fields (ถ้า backend include มา)
  lastMessageText?: string | null;
  unreadCount?: number | null;
};

export type ChatMessage = {
  id: string;
  botId: string;
  sessionId: string;
  platform?: string;
  from: "user" | "admin" | string;
  type: "TEXT" | "IMAGE" | "FILE" | "STICKER" | string;
  text?: string | null;

  // สำหรับ LINE/Platform mapping
  platformMessageId?: string | null;

  // attachment
  attachmentUrl?: string | null;
  attachmentMeta?: any;

  createdAt?: string;
};

export type SessionsResp = {
  ok: boolean;
  items: ChatSession[];
};

export type MessagesResp = {
  ok: boolean;
  items: ChatMessage[];
};

export type ReplyReq = {
  text: string;
  type?: "TEXT" | string;
  attachmentUrl?: string | null;
  attachmentMeta?: any;
};

export type ReplyResp = {
  ok: boolean;
  message: ChatMessage | null;
  error?: string;
};

export type SearchResp = { ok: boolean; items: ChatMessage[] };

/* ------------------------------- API Object ------------------------------ */

export const api = {
  base: API_BASE,

  // Public-ish
  health: () => j<Health>("/api/health"),
  daily: (botId: string) =>
    j<DailyResp>(`/api/stats/daily?botId=${encodeURIComponent(botId)}`),
  recent: (botId: string, limit = 20) =>
    j<RecentResp>(
      `/api/cases/recent?botId=${encodeURIComponent(botId)}&limit=${limit}`
    ),

  // Bots (จาก log คุณมี GET /api/bots)
  bots: () => j<BotsResp>("/api/bots"),

  /* -------------------- Chat Center (แก้จุด messages) -------------------- */

  /**
   * โหลดรายการห้อง (sessions)
   * GET /api/admin/chat/sessions?botId=...&limit=...
   */
  chatSessions: (botId: string, limit = 50) =>
    j<SessionsResp>(
      `/api/admin/chat/sessions?botId=${encodeURIComponent(botId)}&limit=${limit}`
    ),

  /**
   * โหลดข้อความตามห้อง (สำคัญสุด)
   * GET /api/admin/chat/sessions/:sessionId/messages?limit=...
   *
   * >>> ตัวนี้คือคำตอบของปัญหา messages?limit=200 <<<
   */
  chatMessages: (sessionId: string, limit = 200) =>
    j<MessagesResp>(
      `/api/admin/chat/sessions/${encodeURIComponent(sessionId)}/messages?limit=${limit}`
    ),

  /**
   * ส่งข้อความจากแอดมิน
   * POST /api/admin/chat/sessions/:sessionId/reply
   */
  chatReply: (sessionId: string, payload: ReplyReq) =>
    j<ReplyResp>(`/api/admin/chat/sessions/${encodeURIComponent(sessionId)}/reply`, {
      method: "POST",
      body: payload as any,
    }),

  /**
   * Search ในแชท
   * GET /api/admin/chat/search?q=...&botId=...&limit=...
   */
  chatSearch: (q: string, botId: string, limit = 50) =>
    j<SearchResp>(
      `/api/admin/chat/search?q=${encodeURIComponent(q)}&botId=${encodeURIComponent(
        botId
      )}&limit=${limit}`
    ),

  /**
   * Rich message
   * POST /api/admin/chat/rich-message
   */
  chatRichMessage: (payload: any) =>
    j<{ ok: boolean; messageId?: string }>(`/api/admin/chat/rich-message`, {
      method: "POST",
      body: payload,
    }),

  /* ----------------------------- SSE helper ----------------------------- */

  /**
   * ใช้ทำ URL ให้ EventSource (ถ้าคุณอยากประกอบ URL จากที่เดียว)
   * /api/events?tenant=bn9
   */
  eventsUrl: (tenant: string) => `${API_BASE}/api/events?tenant=${encodeURIComponent(tenant)}`,
};
